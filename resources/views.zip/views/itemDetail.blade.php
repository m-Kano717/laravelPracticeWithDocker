<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <title>PHPPractice</title>
</head>
<body>
    <header>
        <h1>PHP練習ショップ</h1>
        @if(session("name"))
            <p>{{session("name")}}さん</p>
            <a href="{{url('/logOut')}}">ログアウト</a>
        @else
            <a href="{{url('/')}}">ログイン</a>
        @endif
    </header>
    <div class="navi">
        <ul>
            <li><a href="{{url('/showTop')}}">トップ</a></li>
            <li><a href="{{url('/showItems')}}">商品一覧</a></li>
            <li>買い物かご</li>
            <li>注文一覧</li>
        </ul>
    </div>
    <h3>商品詳細：{{$items->item_name}}</h3>      
    <ul>
        <li>商品ID：{{$items->id}}</li>
        <li>商品名：<a href="{{route('itemDetail', $items->id)}}">{{$items->item_name}}</a></li>
        <li>カテゴリー：{{ $items->categories?->categorie_name }}</li>
        <li>価格：￥{{$items->price}}</li>
    </ul>
    </table>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <title>PHPPractice</title>
</head>
<body>
    <header>
        <h1>PHP練習ショップ</h1>
        @if(session("name"))
            <p>{{session("name")}}さん</p>
            <a href="{{url('/logOut')}}">ログアウト</a>
        @else
            <a href="{{url('/')}}">ログイン</a>
            <a href="{{url('/registUser')}}">新規会員登録</a>
        @endif
    </header>
    <div class="navi">
        <ul>
            <li><a href="{{url('/showTop')}}">トップ</a></li>
            <li><a href="{{url('/showItems')}}">商品一覧</a></li>
            <li>買い物かご</li>
            <li>注文一覧</li>
        </ul>
    </div>
    <h3>本日のおすすめ</h3>
    @foreach($randomItems as $item)
    <ul>
        <li><a href="{{route('itemDetail', $item->id)}}">{{$item->item_name}}</a></li>
        <li>{{$item->categories?->categorie_name}}</li>
        <li>{{$item->price}}</li>
    </ul>
    @endforeach
    
</body>
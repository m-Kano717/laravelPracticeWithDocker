<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <title>PHPPractice</title>
</head>
<body>
    <header>
        <h1>PHP練習ショップ</h1>
        @if(session("name"))
            <p>{{session("name")}}さん</p>
            <a href="{{url('/logOut')}}">ログアウト</a>
        @else
            <a href="{{url('/')}}">ログイン</a>
        @endif
    </header>
    <div class="navi">
        <ul>
            <li><a href="{{url('/showTop')}}">トップ</a></li>
            <li><a href="{{url('/showItems')}}">商品一覧</a></li>
            <li>買い物かご</li>
            <li>注文一覧</li>
        </ul>
    </div>
    <h3>新規会員登録</h3>
    <p>メールを送信します。</p>
    <form method="Get">
        @csrf
        メールアドレス：<input type="email" name="mail"><br>
        <input type="submit" value="送信">
    </form>

<p>番号入力</p>
<form method="Post" action="/registCheck">
    @csrf
    <input type="number" name="num">
</form>

</body>
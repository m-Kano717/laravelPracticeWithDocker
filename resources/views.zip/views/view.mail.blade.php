<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <title>testTest</title>
</head>
<body>
    <p>testNumber</p>
    <h1>{{$randomNum}}</h1>
</body>
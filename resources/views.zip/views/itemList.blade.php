<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <title>PHPPractice</title>
</head>
<body>
    <header>
        <h1>PHP練習ショップ</h1>
        @if(session("name"))
            <p>{{session("name")}}さん</p>
            <a href="{{url('/logOut')}}">ログアウト</a>
        @else
            <a href="{{url('/')}}">ログイン</a>
        @endif
    </header>
    <div class="navi">
        <ul>
            <li><a href="{{url('/showTop')}}">トップ</a></li>
            <li><a href="{{url('/showItems')}}">商品一覧</a></li>
            <li>買い物かご</li>
            <li>注文一覧</li>
        </ul>
    </div>
    <table>
        <tr>
            <th>商品ID</th>
            <th>商品名</th>
            <th>カテゴリー</th>
            <th>価格</th>
        </tr>
        @foreach($itemList as $items)
        <tr>
            <td>{{$items->id}}</td>
            <td><a href="{{route('itemDetail', $items->id)}}">{{$items->item_name}}</a></td>
            <td>{{ $items->categories?->categorie_name }}</td>
            <td>{{$items->price}}</td>
        </tr>
        @endforeach
    </table>

</body>
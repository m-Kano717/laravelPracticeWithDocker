<!DOCTYPE html>
<html lang="ja">
<style>
    header{
        margin: 0px;
        background-color: blue;
    }
    header h1{
        margin-left: 20px;
    }
    contents{
        text-align: center;
    }
    .form{
        background-color: green;
        padding: 5px;
    }
</style>
<head>
    <meta charset="utf-8">
    <title>PHPPractice</title>
</head>
<body>
    <header>
    <h1>PHP練習ショップ</h1>
    </header>
    <contents>
    <p>ログイン</p>
    <div class="form">
    <form action="/formPractice" method="POST">
        @csrf
        @error("name")
        <p style="color: red;">{{$message}}</p>
        @enderror
        @error("pass")
        <p style="color: red;">{{$message}}</p>
        @enderror
        名前：<input type="text" name="name" value="{{ old('name') }}" >
        <br>
        パスワード：<input type="password" name="pass" value="">
        <br>
        <input type="submit" value="送信">
    </form>
</div>
    </contents>
</body>
</html>